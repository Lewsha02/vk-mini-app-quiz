self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4cae55702df1ac6d171e3757bd7a90eb",
    "url": "/index.html"
  },
  {
    "revision": "9aeb7c3a3fb1fb1eeb2d",
    "url": "/static/js/2.b924a1ec.chunk.js"
  },
  {
    "revision": "9757b3dffe8a3780a5ee2a1f84cb7f72",
    "url": "/static/js/2.b924a1ec.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b865e7f525432161b036",
    "url": "/static/js/main.09dbebd1.chunk.js"
  },
  {
    "revision": "df22a400bd5a88d3fa8e",
    "url": "/static/js/runtime-main.d9e5ff9a.js"
  },
  {
    "revision": "8ff2cf46728f5eb62a6888a5d8a13a7d",
    "url": "/static/media/edit.8ff2cf46.svg"
  }
]);