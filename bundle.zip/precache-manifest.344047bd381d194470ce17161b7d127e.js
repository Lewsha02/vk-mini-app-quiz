self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c7685b325f0cec366ddd8038bce766ab",
    "url": "/index.html"
  },
  {
    "revision": "9aeb7c3a3fb1fb1eeb2d",
    "url": "/static/js/2.b924a1ec.chunk.js"
  },
  {
    "revision": "9757b3dffe8a3780a5ee2a1f84cb7f72",
    "url": "/static/js/2.b924a1ec.chunk.js.LICENSE.txt"
  },
  {
    "revision": "eed35a57cd7a99886315",
    "url": "/static/js/main.d0d623b7.chunk.js"
  },
  {
    "revision": "df22a400bd5a88d3fa8e",
    "url": "/static/js/runtime-main.d9e5ff9a.js"
  },
  {
    "revision": "8ff2cf46728f5eb62a6888a5d8a13a7d",
    "url": "/static/media/edit.8ff2cf46.svg"
  }
]);