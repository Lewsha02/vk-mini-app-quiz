self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "336947e2e06d39d02062243346a932f1",
    "url": "/index.html"
  },
  {
    "revision": "ef805e2fcbc281da32ce",
    "url": "/static/js/2.60247f8c.chunk.js"
  },
  {
    "revision": "9757b3dffe8a3780a5ee2a1f84cb7f72",
    "url": "/static/js/2.60247f8c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "310a5f0b21b2abcdae4e",
    "url": "/static/js/main.fefe20a9.chunk.js"
  },
  {
    "revision": "df22a400bd5a88d3fa8e",
    "url": "/static/js/runtime-main.d9e5ff9a.js"
  },
  {
    "revision": "8ff2cf46728f5eb62a6888a5d8a13a7d",
    "url": "/static/media/edit.8ff2cf46.svg"
  }
]);