self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "04ee6da78c6a8819bfd96086f85a95e0",
    "url": "/index.html"
  },
  {
    "revision": "a4a35d2f5d0c4748f561",
    "url": "/static/js/2.ed8aa62b.chunk.js"
  },
  {
    "revision": "9757b3dffe8a3780a5ee2a1f84cb7f72",
    "url": "/static/js/2.ed8aa62b.chunk.js.LICENSE.txt"
  },
  {
    "revision": "0053b93810d4642d3721",
    "url": "/static/js/main.1943ca89.chunk.js"
  },
  {
    "revision": "df22a400bd5a88d3fa8e",
    "url": "/static/js/runtime-main.d9e5ff9a.js"
  },
  {
    "revision": "8ff2cf46728f5eb62a6888a5d8a13a7d",
    "url": "/static/media/edit.8ff2cf46.svg"
  }
]);